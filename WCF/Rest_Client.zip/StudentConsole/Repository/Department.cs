﻿namespace StudentConsole.Repository
{
    public class Department
    {
        public int DepartmentId { get; set; }
        public string ShortName { get; set; }
        public string Name { get; set; }
    }


}
