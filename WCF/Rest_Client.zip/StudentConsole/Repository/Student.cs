﻿using System;

namespace StudentConsole.Repository
{
    public class Student
    {
        public Student()
        {
            
        }

        public int? StudentId { get; set; }
        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public string EmailAddress { get; set; }

        public string Phone { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int Gender { get; set; }

        public int DepartmentId { get; set; }

        public int CategoryId { get; set; }

        public bool IsActive { get; set; }
    }


    public class StudentDetails : Student
    {
        public string DepartmentName { get; set; }
    
        public string CategoryName { get; set; }

    }
}
