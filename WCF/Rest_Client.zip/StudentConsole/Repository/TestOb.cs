﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentConsole.Repository
{
    public class TestRequestObj
    {
        public int num1 { get; set; }
        public int num2 { get; set; }
    }

    public class TestResponse
    {
        public int SubResult { get; set; }
    }
}
