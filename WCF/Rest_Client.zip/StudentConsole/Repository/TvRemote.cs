﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentConsole.Repository
{
    public class TvRemote :IRemote
    {
        public void TurnOff()
        {
            Console.WriteLine("TV Turn Off");
        }

        public void TurnOn()
        {
            Console.WriteLine("TV Turn On");
        }
    }
}
